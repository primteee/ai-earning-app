package com.aitools.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.aitools.app.ui.theme.AIToolsTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AIToolsTheme {
                // Simple content: call AiWriterScreen directly for starter
                androidx.compose.material.Surface {
                    com.aitools.app.ui.screens.AiWriterScreen(
                        viewModel = com.aitools.app.viewmodel.AiViewModel(
                            repo = com.aitools.app.repo.AiRepository(
                                api = com.aitools.app.network.NetworkModule.apiService
                            )
                        )
                    )
                }
            }
        }
    }
}
