package com.aitools.app.network

import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

data class AiRequest(val tool: String, val input: String)
data class AiResponse(val text: String?, val outputUrl: String?, val cost: Int)

interface ApiService {
    @POST("/api/v1/ai/generate")
    suspend fun generate(@Body req: AiRequest): AiResponse

    @GET("/api/v1/user/balance")
    suspend fun getBalance(): Map<String, Any>
}
