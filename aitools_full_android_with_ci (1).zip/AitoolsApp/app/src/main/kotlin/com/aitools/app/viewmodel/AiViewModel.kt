package com.aitools.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aitools.app.repo.AiRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class AiViewModel(private val repo: AiRepository): ViewModel() {
    private val _output = MutableStateFlow("")
    val output: StateFlow<String> = _output

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    suspend fun generate(tool:String, input:String) {
        _loading.value = true
        try {
            val res = repo.generate(tool, input)
            _output.value = res.text ?: "(no text)"
        } catch(e:Exception) {
            _output.value = "Error: ${e.localizedMessage}"
        }
        _loading.value = false
    }
}
