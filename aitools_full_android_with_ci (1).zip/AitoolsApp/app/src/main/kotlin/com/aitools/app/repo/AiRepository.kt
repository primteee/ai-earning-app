package com.aitools.app.repo

import com.aitools.app.network.AiRequest
import com.aitools.app.network.ApiService

class AiRepository(private val api: ApiService) {
    suspend fun generate(tool:String, input:String) = api.generate(AiRequest(tool,input))
    suspend fun getBalance() = api.getBalance()
}
