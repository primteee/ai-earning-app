package com.aitools.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@Composable
fun AiWriterScreen(viewModel: com.aitools.app.viewmodel.AiViewModel) {
    val scope = rememberCoroutineScope()
    var prompt by remember { mutableStateOf("") }
    val output by viewModel.output.collectAsState()
    val loading by viewModel.loading.collectAsState()

    Column(modifier = Modifier.padding(16.dp)) {
        Text("AI Writer", style = MaterialTheme.typography.h5)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = prompt, onValueChange = { prompt = it }, label = { Text("Enter prompt...") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            scope.launch { viewModel.generate("text", prompt) }
        }, enabled = !loading) {
            Text(if (loading) "Generating..." else "Generate")
        }
        Spacer(Modifier.height(16.dp))
        Text("Output:")
        Divider()
        Text(output)
    }
}
