package com.aitools.app.payment

import android.app.Activity
import android.util.Log
import org.json.JSONObject
import com.razorpay.Checkout

class RazorpayHelper(private val activity: Activity) {

    init {
        Checkout.preload(activity.applicationContext)
    }

    fun startCheckout(orderId: String, amountPaise: Int) {
        val co = Checkout()
        // Key ideally should come from your backend or secured source
        co.setKeyID("rzp_test_xxx")
        val options = JSONObject()
        options.put("name", "AI Tools")
        options.put("description", "Buy Coins")
        options.put("order_id", orderId)
        options.put("currency", "INR")
        options.put("amount", amountPaise)
        try {
            co.open(activity, options)
        } catch (e: Exception) {
            Log.e("Razorpay", "Error in starting Razorpay Checkout", e)
        }
    }
}
