package com.aitools.app.billing

import android.app.Activity
import androidx.lifecycle.lifecycleScope
import com.android.billingclient.api.*
import kotlinx.coroutines.launch

class BillingManager(private val activity: Activity, private val listener: PurchaseListener) : PurchasesUpdatedListener {

    private val billingClient = BillingClient.newBuilder(activity)
        .enablePendingPurchases()
        .setListener(this)
        .build()

    fun startConnection() {
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(billingResult: BillingResult) {
                if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    // ready
                }
            }
            override fun onBillingServiceDisconnected() { /* retry logic */ }
        })
    }

    fun purchaseProduct(skuId: String) {
        val params = BillingFlowParams.newBuilder()
            .setSkuDetails(SkuDetails(/* dummy - fetch via querySkuDetailsAsync */))
            .build()
        // you must query SkuDetails first, this is just placeholder
    }

    override fun onPurchasesUpdated(billingResult: BillingResult, purchases: MutableList<Purchase>?) {
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (purchase in purchases) {
                // Acknowledge and grant coins
                listener.onPurchaseSuccess(purchase)
            }
        } else {
            listener.onPurchaseFailed(billingResult.responseCode, billingResult.debugMessage)
        }
    }

    interface PurchaseListener {
        fun onPurchaseSuccess(purchase: Purchase)
        fun onPurchaseFailed(code: Int, message: String?)
    }
}
