# CI & Signing Instructions (Keystore + GitHub Actions)

## 1) Generate a release keystore locally (on your PC)
Run in terminal (replace alias and passwords as needed):
```
keytool -genkey -v -keystore release-keystore.jks -alias aitoolskey -keyalg RSA -keysize 2048 -validity 10000
```
This will ask for passwords and fields. Remember the alias and passwords.

## 2) Encode keystore to base64 to store in GitHub secret
```
base64 release-keystore.jks > release-keystore.jks.base64
# copy the content of release-keystore.jks.base64
```

## 3) Add GitHub repository secrets (Settings -> Secrets -> Actions)
- `APK_SIGNING_KEY` : contents of `release-keystore.jks.base64` (full base64 text)
- `KEYSTORE_PASSWORD` : keystore password
- `KEY_ALIAS` : alias used (e.g., aitoolskey)
- `KEY_PASSWORD` : alias key password

## 4) Push to GitHub main branch
Workflow `.github/workflows/android-build-aab.yml` will run and produce `app-release.aab` artifact.

## 5) For Play Console upload:
- Use the produced `.aab` and upload to internal testing / production.
- Make sure Play Billing items are configured in Play Console if you use Play Billing for in-app purchases.

## Notes
- For CI you can also store `google-services.json` in GitHub secrets and write a workflow step to create the file during build if needed.
- Keep your keystore safe and backup securely.
